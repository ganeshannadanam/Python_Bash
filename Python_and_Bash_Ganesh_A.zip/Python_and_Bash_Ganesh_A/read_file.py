# Task 4: Read from a File
# Opens the file in read mode and displays content using file.read().

file = open("sample.txt", "r")
content = file.read()
file.close()

print("Content of sample.txt:\n")
print(content)
