# Task 3: Write to a File
# Creates a text file and writes content to it using open() and write().

file = open("sample.txt", "w")
file.write("Hello, this is Ganesh A.\n")
file.write("This file was created using Python.\n")
file.write("Python and Bash - DevOps Assignment.\n")
file.close()

print("File 'sample.txt' created and content written successfully.")
